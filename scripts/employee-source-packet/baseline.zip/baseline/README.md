# Legacy.Maliev.EmployeeService

Public, sanitized .NET 10 compatibility extraction of the employee domain from the
private `maliev-web` monorepo. It preserves employee, address, role, signature
metadata, pagination, and sort contracts while replacement services are completed
independently.

## Architecture and security boundaries

Dependency direction is `Api -> Application -> Domain`; PostgreSQL and Redis
adapters live in `Data`. Scalar/OpenAPI, JWT validation, standard
middleware, health endpoints, resilience, and structured logging come from
the public `Legacy.Maliev.ServiceDefaults` package while preserving the existing
`Maliev.Aspire.ServiceDefaults` CLR namespace. CI and image builds also use the public
`Legacy.Maliev.CompatibilityContracts` source repository, so the legacy service no longer depends
on new-platform shared-library source or private package credentials.

EmployeeService neither opens, migrates, nor proxies `EmployeeIdentity`. Passwords,
password hashes, security stamps, authenticator keys, recovery material, sessions,
tokens, credential validation, and identity administration are owned exclusively by
`Legacy.Maliev.AuthService`.

Employee self-profile writes use a two-stage trust boundary. The same-origin
`Legacy.Maliev.Intranet.Bff` accepts no browser-supplied employee ID; it derives the
target employee database ID exclusively from the signed `legacy_database_id` in the
authenticated employee session. It then calls the narrow EmployeeService endpoint
with its service token, which additionally carries the dedicated exact permission
`legacy-employee.employees.self-update`. EmployeeService accepts only first name,
last name, phone number, and date of birth; unknown JSON members are rejected and
role, email, address, identity, and security fields remain server-owned.

## Preserved route families

- `/Employees[/{id}]` and `/Employees?sort=&search=&index=&size=`
- `PUT /Employees/{employeeId}/profile` (trusted Intranet BFF self-service only)
- `/employees/addresses[/{addressId}]`
- `/employees/roles[/{roleId}]`
- `/employees/signatures[/{employeeId}]`
- `/employees/{employeeId}/signatures`

PascalCase JSON, null omission, the four legacy sort values, named routes and the
pagination fields `Items`, `PageIndex`, `TotalPages`, `TotalRecords`,
`HasNextPage`, and `HasPreviousPage` remain compatible. List size is bounded to
250 records to protect the existing cluster.

## Data, signatures and caching

- PostgreSQL target: the employee logical database in `legacy-postgres-<environment>`
  in `maliev-legacy` after parity gates.
- Preserved tables: `Employee`, `Address`, `Role`, `SignatureImageFile`, including
  legacy `ID`/foreign-key names, lengths, computed `FullName`, and FK names.
- `EmployeeIdentity` remains in AuthService and source SQL Server is untouched.
- Signature rows contain Google Cloud Storage bucket/object metadata only. Runtime
  object access must use ADC/Workload Identity; no service-account keys are stored.
- Redis prefix: `legacy:employee:`; authorized employee projections are short-lived,
  fail open to PostgreSQL, and are invalidated after employee/address/role changes.

## External scaffold preview

`Legacy.Maliev.EmployeeService.Data/ScaffoldContext.ps1` prepares a separate
`EmployeeScaffoldContext` preview from an externally configured target database.
Supply `ConnectionStrings__EmployeeDbContext` through the process environment,
use an available `dotnet ef` tool with prebuilt Release API/Data output, and pass
`-OutputDirectory` with a new absolute directory outside this repository.
The preview selects only `Employee`, `Address`, `Role`, and `SignatureImageFile`.
It leaves the registered runtime context and existing files unchanged and passes
the connection's setting name, rather than its value, to the tool.

CI runs `tooling/Test-EmployeeScaffoldContract.ps1` against a recorded CLI boundary
and preserves its guard evidence with the ordinary validation artifacts. These
checks do not prove real EF named-connection resolution, generated-code
compilation, source database parity, or cutover readiness. Source SQL Server and
legacy credential resources must never be supplied or refreshed by this tool.

`EnableEmployeeScaffoldDesignTime=true` opts into a private API Design dependency
for tooling only; the default API dependency graph remains unchanged. Build this
mode into an external `ArtifactsPath`, retaining exact local dependency refs.
The actual-EF hosted regression uses the existing disposable fixture and records
sanitized generation, preview compilation, generated-model/query and cleanup
evidence. See `docs/employee-actual-scaffold-proof-20261006.md`; until executed,
these checks remain unaccepted and do not establish source SQL Server parity.

## Deployment gate

Extraction does not deploy. Cutover requires a dedicated `legacy-maliev-employee`
WIF identity, `maliev-gitops/3-apps/_legacy-employee-service`, the AuthService
employee-identity API, data parity/rollback evidence, signature-object
reconciliation, and Web/Intranet consumer tests.

The repository provides a gated immutable-image workflow and a namespace-confined,
non-root base manifest for that future cutover. Runtime database, Redis, and JWT
verification values are projected from `legacy-maliev-employee-runtime`; identity,
credential, token, and session configuration is intentionally absent.

Everything must use the existing GKE cluster and `maliev-legacy` namespace with no
new node pool, Cloud SQL, or other paid database service.

## Validate

```powershell
dotnet restore
dotnet build --no-restore
dotnet test --no-build
dotnet format Legacy.Maliev.EmployeeService.slnx --verify-no-changes --no-restore
dotnet list package --vulnerable --include-transitive
gitleaks git . --redact=100 --exit-code 1 --no-banner --no-color
```
