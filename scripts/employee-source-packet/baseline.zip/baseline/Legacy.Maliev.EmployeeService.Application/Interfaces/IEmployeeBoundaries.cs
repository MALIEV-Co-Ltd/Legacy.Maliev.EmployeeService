using Legacy.Maliev.EmployeeService.Application.Models;
using Legacy.Maliev.EmployeeService.Domain;

namespace Legacy.Maliev.EmployeeService.Application.Interfaces;

/// <summary>Employee application boundary.</summary>
public interface IEmployeeService
{
    /// <summary>Fences the employee version, address binding and address version in one transaction.</summary>
    Task<EmployeeHomeAddressEditResult> UpdateHomeAddressIfMatchAsync(int id, EmployeeHomeAddressEditRequest request, string employeeVersion, string addressVersion, CancellationToken cancellationToken);
    /// <summary>Gets one employee.</summary>
    Task<EmployeeResponse?> GetEmployeeAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets a bounded employee page.</summary>
    Task<PaginatedResponse<EmployeeResponse>?> GetEmployeesAsync(EmployeeSortType? sort, string? search, int? index, int? size, CancellationToken cancellationToken);
    /// <summary>Creates an employee.</summary>
    Task<EmployeeResponse> CreateEmployeeAsync(UpsertEmployeeRequest request, CancellationToken cancellationToken);
    /// <summary>Updates an employee.</summary>
    Task<bool> UpdateEmployeeAsync(int id, UpsertEmployeeRequest request, CancellationToken cancellationToken);
    /// <summary>Updates the employee only if the supplied edit version still matches.</summary>
    Task<EmployeeEditResult> UpdateEmployeeIfMatchAsync(int id, UpsertEmployeeRequest request, string version, CancellationToken cancellationToken);
    /// <summary>Updates only employee-owned profile fields.</summary>
    Task<bool> UpdateSelfProfileAsync(int id, UpdateEmployeeSelfProfileRequest request, CancellationToken cancellationToken);
    /// <summary>Deletes an employee.</summary>
    Task<bool> DeleteEmployeeAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets all employee addresses.</summary>
    Task<IReadOnlyList<AddressResponse>> GetAddressesAsync(CancellationToken cancellationToken);
    /// <summary>Gets one employee address.</summary>
    Task<AddressResponse?> GetAddressAsync(int id, CancellationToken cancellationToken);
    /// <summary>Creates an employee address.</summary>
    Task<AddressResponse> CreateAddressAsync(UpsertAddressRequest request, CancellationToken cancellationToken);
    /// <summary>Updates an employee address.</summary>
    Task<bool> UpdateAddressAsync(int id, UpsertAddressRequest request, CancellationToken cancellationToken);
    /// <summary>Updates the address only if the supplied edit version still matches.</summary>
    Task<EmployeeEditResult> UpdateAddressIfMatchAsync(int id, UpsertAddressRequest request, string version, CancellationToken cancellationToken);
    /// <summary>Deletes an employee address.</summary>
    Task<bool> DeleteAddressAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets all employee roles.</summary>
    Task<IReadOnlyList<RoleResponse>> GetRolesAsync(CancellationToken cancellationToken);
    /// <summary>Gets one employee role.</summary>
    Task<RoleResponse?> GetRoleAsync(int id, CancellationToken cancellationToken);
    /// <summary>Creates an employee role.</summary>
    Task<RoleResponse> CreateRoleAsync(UpsertRoleRequest request, CancellationToken cancellationToken);
    /// <summary>Updates an employee role.</summary>
    Task<bool> UpdateRoleAsync(int id, UpsertRoleRequest request, CancellationToken cancellationToken);
    /// <summary>Deletes an employee role.</summary>
    Task<bool> DeleteRoleAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets signature metadata for one employee.</summary>
    Task<SignatureImageFileResponse?> GetSignatureAsync(int employeeId, CancellationToken cancellationToken);
    /// <summary>Creates signature metadata for one employee.</summary>
    Task<SignatureImageFileResponse?> CreateSignatureAsync(int employeeId, UpsertSignatureImageFileRequest request, CancellationToken cancellationToken);
    /// <summary>Updates signature metadata for one employee.</summary>
    Task<bool> UpdateSignatureAsync(int employeeId, UpsertSignatureImageFileRequest request, CancellationToken cancellationToken);
    /// <summary>Deletes signature metadata for one employee.</summary>
    Task<bool> DeleteSignatureAsync(int employeeId, CancellationToken cancellationToken);
}

/// <summary>Employee PostgreSQL persistence boundary.</summary>
public interface IEmployeeRepository
{
    /// <summary>Locks the employee and its captured address before comparing either version or writing.</summary>
    Task<EmployeeHomeAddressEditResult> UpdateHomeAddressIfMatchAsync(int id, EmployeeHomeAddressEditRequest request, string employeeVersion, string addressVersion, CancellationToken cancellationToken);
    /// <summary>Gets one employee projection.</summary>
    Task<EmployeeResponse?> GetEmployeeAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets a bounded employee page.</summary>
    Task<PaginatedResponse<EmployeeResponse>?> GetEmployeesAsync(EmployeeSortType? sort, string? search, int pageIndex, int pageSize, CancellationToken cancellationToken);
    /// <summary>Creates an employee entity.</summary>
    Task<Employee> CreateEmployeeAsync(UpsertEmployeeRequest request, CancellationToken cancellationToken);
    /// <summary>Updates an employee entity.</summary>
    Task<bool> UpdateEmployeeAsync(int id, UpsertEmployeeRequest request, CancellationToken cancellationToken);
    /// <summary>Compares and updates the employee under one PostgreSQL row lock.</summary>
    Task<EmployeeEditResult> UpdateEmployeeIfMatchAsync(int id, UpsertEmployeeRequest request, string version, CancellationToken cancellationToken);
    /// <summary>Atomically updates only employee-owned profile fields.</summary>
    Task<bool> UpdateSelfProfileAsync(int id, UpdateEmployeeSelfProfileRequest request, CancellationToken cancellationToken);
    /// <summary>Deletes an employee entity.</summary>
    Task<bool> DeleteEmployeeAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets address projections.</summary>
    Task<IReadOnlyList<AddressResponse>> GetAddressesAsync(CancellationToken cancellationToken);
    /// <summary>Gets an address projection.</summary>
    Task<AddressResponse?> GetAddressAsync(int id, CancellationToken cancellationToken);
    /// <summary>Creates an address entity.</summary>
    Task<Address> CreateAddressAsync(UpsertAddressRequest request, CancellationToken cancellationToken);
    /// <summary>Updates an address entity.</summary>
    Task<bool> UpdateAddressAsync(int id, UpsertAddressRequest request, CancellationToken cancellationToken);
    /// <summary>Compares and updates the address under one PostgreSQL row lock.</summary>
    Task<EmployeeEditResult> UpdateAddressIfMatchAsync(int id, UpsertAddressRequest request, string version, CancellationToken cancellationToken);
    /// <summary>Gets employees whose cached projection references an address.</summary>
    Task<IReadOnlyList<int>> GetEmployeeIdsForAddressAsync(int id, CancellationToken cancellationToken);
    /// <summary>Deletes an address entity.</summary>
    Task<bool> DeleteAddressAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets role projections.</summary>
    Task<IReadOnlyList<RoleResponse>> GetRolesAsync(CancellationToken cancellationToken);
    /// <summary>Gets a role projection.</summary>
    Task<RoleResponse?> GetRoleAsync(int id, CancellationToken cancellationToken);
    /// <summary>Creates a role entity.</summary>
    Task<Role> CreateRoleAsync(UpsertRoleRequest request, CancellationToken cancellationToken);
    /// <summary>Updates a role entity.</summary>
    Task<bool> UpdateRoleAsync(int id, UpsertRoleRequest request, CancellationToken cancellationToken);
    /// <summary>Gets employees whose cached projection references a role.</summary>
    Task<IReadOnlyList<int>> GetEmployeeIdsForRoleAsync(int id, CancellationToken cancellationToken);
    /// <summary>Deletes a role entity.</summary>
    Task<bool> DeleteRoleAsync(int id, CancellationToken cancellationToken);
    /// <summary>Gets signature metadata by employee identifier.</summary>
    Task<SignatureImageFileResponse?> GetSignatureAsync(int employeeId, CancellationToken cancellationToken);
    /// <summary>Creates signature metadata.</summary>
    Task<SignatureImageFile?> CreateSignatureAsync(int employeeId, UpsertSignatureImageFileRequest request, CancellationToken cancellationToken);
    /// <summary>Updates signature metadata.</summary>
    Task<bool> UpdateSignatureAsync(int employeeId, UpsertSignatureImageFileRequest request, CancellationToken cancellationToken);
    /// <summary>Deletes signature metadata.</summary>
    Task<bool> DeleteSignatureAsync(int employeeId, CancellationToken cancellationToken);
}

/// <summary>Short-lived Redis cache for authorized employee reads.</summary>
public interface IEmployeeCache
{
    /// <summary>Gets a cached employee projection.</summary>
    Task<EmployeeResponse?> GetAsync(int id, CancellationToken cancellationToken);
    /// <summary>Stores a cached employee projection.</summary>
    Task SetAsync(EmployeeResponse employee, CancellationToken cancellationToken);
    /// <summary>Removes a cached employee projection.</summary>
    Task RemoveAsync(int id, CancellationToken cancellationToken);
}
