using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Legacy.Maliev.EmployeeService.Domain;
using Microsoft.EntityFrameworkCore;
using Xunit.Abstractions;

namespace Legacy.Maliev.EmployeeService.Tests;

[Collection("Employee signature persistence")]
public sealed class EmployeeSignatureOwnerBoundaryHttpTests(EmployeeRouteAcceptanceFixture fixture, ITestOutputHelper output)
    : IClassFixture<EmployeeRouteAcceptanceFixture>
{
    [Theory]
    [InlineData(18, false)]
    [InlineData(0, false)]
    [InlineData(int.MaxValue, false)]
    [InlineData(18, true)]
    [InlineData(0, true)]
    [InlineData(int.MaxValue, true)]
    public async Task DifferentBodyOwner_RejectsBeforeMetadataLookupAndPreservesEveryRow(int bodyOwner, bool duplicate)
    {
        await SeedAsync(duplicate);
        var before = await SnapshotAsync();
        using var client = fixture.Client("legacy-employee.signatures.write", "/employees/17/signature");
        using var response = await client.PutAsJsonAsync("/employees/signatures/17",
            new { EmployeeId = bodyOwner, Bucket = "replacement", ObjectName = "replacement.png" });
        await using var db = fixture.CreateContext();
        var selected = await db.SignatureImageFiles.AsNoTracking().SingleAsync(row => row.Id == 101);
        var after = await SnapshotAsync();
        output.WriteLine($"BASELINE_SIGNATURE_OWNER routeOwner=17 bodyOwner={bodyOwner} duplicate={duplicate} httpStatus={(int)response.StatusCode} selectedId={selected.Id} observedOwner={selected.EmployeeId} graphUnchanged={before == after}");
        fixture.IamTransportEvidence.AssertHealthy();
        Assert.Equal(17, selected.EmployeeId);
        Assert.Equal(before, after);
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Theory]
    [InlineData("same")]
    [InlineData("omitted")]
    [InlineData("null")]
    public async Task AuthorizedOwner_DefaultAdaptationRetainsRouteIdentityAndUpdatesOnlySelectedMetadata(string ownerShape)
    {
        await SeedAsync(false);
        var before = await SnapshotAsync(101);
        var payload = ownerShape switch
        {
            "same" => "{\"EmployeeId\":17,\"Bucket\":\"replacement\",\"ObjectName\":\"replacement.png\"}",
            "null" => "{\"EmployeeId\":null,\"Bucket\":\"replacement\",\"ObjectName\":\"replacement.png\"}",
            _ => "{\"Bucket\":\"replacement\",\"ObjectName\":\"replacement.png\"}"
        };
        using var client = fixture.Client("legacy-employee.signatures.write", "/employees/17/signature");
        using var content = new StringContent(payload, Encoding.UTF8, "application/json");
        using var response = await client.PutAsync("/employees/signatures/17", content);
        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
        Assert.Equal(string.Empty, await response.Content.ReadAsStringAsync());
        Assert.Equal(before, await SnapshotAsync(101));
        await using var db = fixture.CreateContext();
        var stored = await db.SignatureImageFiles.AsNoTracking().SingleAsync(row => row.Id == 101);
        Assert.Equal(17, stored.EmployeeId);
        Assert.Equal("replacement", stored.Bucket);
        Assert.Equal("replacement.png", stored.ObjectName);
        Assert.Equal(new DateTime(2020, 1, 1), stored.CreatedDate);
        Assert.True(stored.ModifiedDate > new DateTime(2020, 1, 2));
        using var reader = fixture.Client("legacy-employee.signatures.read", "/employees/17/signature");
        using var read = await reader.GetAsync("/employees/signatures/17");
        Assert.Equal(HttpStatusCode.OK, read.StatusCode);
        using var json = JsonDocument.Parse(await read.Content.ReadAsStringAsync());
        Assert.Equal(101, json.RootElement.GetProperty("Id").GetInt32());
        Assert.Equal(17, json.RootElement.GetProperty("EmployeeId").GetInt32());
        Assert.Equal("replacement", json.RootElement.GetProperty("Bucket").GetString());
        Assert.Equal("replacement.png", json.RootElement.GetProperty("ObjectName").GetString());
        Assert.False(json.RootElement.TryGetProperty("employeeId", out _));
        Assert.Equal(before, await SnapshotAsync(101));
        fixture.IamTransportEvidence.AssertHealthy();
    }

    [Theory]
    [InlineData("anonymous", HttpStatusCode.Unauthorized)]
    [InlineData("wrong-signature", HttpStatusCode.Unauthorized)]
    [InlineData("missing-permission", HttpStatusCode.Forbidden)]
    public async Task InvalidAuthority_PrecedesOwnerMismatchValidationAndPreservesGraph(
        string authority, HttpStatusCode expected)
    {
        await SeedAsync(false);
        var before = await SnapshotAsync();
        using var client = fixture.Client("legacy-employee.signatures.write",
            "/employees/17/signature", authority: authority);
        using var response = await client.PutAsJsonAsync("/employees/signatures/17",
            new { EmployeeId = 18, Bucket = "replacement", ObjectName = "replacement.png" });
        Assert.Equal(expected, response.StatusCode);
        Assert.Equal(before, await SnapshotAsync());
        Assert.DoesNotContain("synthetic-private", await response.Content.ReadAsStringAsync(),
            StringComparison.OrdinalIgnoreCase);
        fixture.IamTransportEvidence.AssertHealthy();
    }

    private async Task SeedAsync(bool duplicate)
    {
        await using var db = fixture.CreateContext();
        await db.Database.ExecuteSqlRawAsync("TRUNCATE TABLE \"Employee\", \"Address\", \"Role\", \"SignatureImageFile\" RESTART IDENTITY CASCADE");
        db.Addresses.Add(new Address { Id = 201, Building = "Synthetic office", CountryId = 66 });
        db.Roles.Add(new Role { Id = 1, Name = "Synthetic role", Description = null });
        db.Employees.AddRange(
            new Employee { Id = 17, RoleId = 1, HomeAddressId = 201, FirstName = "Owner", LastName = "Synthetic", Email = "owner@example.invalid" },
            new Employee { Id = 18, FirstName = "Other", LastName = "Synthetic", Email = "other@example.invalid" });
        db.SignatureImageFiles.AddRange(
            new SignatureImageFile
            {
                Id = 101, EmployeeId = 17, Bucket = "synthetic-private-owner", ObjectName = "owner.png",
                CreatedDate = new DateTime(2020, 1, 1), ModifiedDate = new DateTime(2020, 1, 2)
            },
            new SignatureImageFile
            {
                Id = 301, EmployeeId = 18, Bucket = "synthetic-private-other", ObjectName = "other.png",
                CreatedDate = new DateTime(2020, 1, 1), ModifiedDate = new DateTime(2020, 1, 2)
            });
        if (duplicate) db.SignatureImageFiles.Add(new SignatureImageFile
        {
            Id = 102, EmployeeId = 17, Bucket = "synthetic-private-duplicate", ObjectName = "duplicate.png",
            CreatedDate = new DateTime(2020, 1, 1), ModifiedDate = new DateTime(2020, 1, 2)
        });
        await db.SaveChangesAsync();
        fixture.Authorities.Clear();
    }

    private async Task<string> SnapshotAsync(int? excludedSignatureId = null)
    {
        await using var db = fixture.CreateContext();
        return JsonSerializer.Serialize(new
        {
            Employees = await db.Employees.AsNoTracking().OrderBy(row => row.Id)
                .Select(row => new { row.Id, row.RoleId, row.FirstName, row.LastName, row.FullName,
                    row.PhoneNumber, row.Email, row.DateOfBirth, row.HomeAddressId, row.CreatedDate, row.ModifiedDate }).ToArrayAsync(),
            Addresses = await db.Addresses.AsNoTracking().OrderBy(row => row.Id)
                .Select(row => new { row.Id, row.Building, row.AddressLine1, row.AddressLine2,
                    row.City, row.State, row.PostalCode, row.CountryId, row.CreatedDate, row.ModifiedDate }).ToArrayAsync(),
            Roles = await db.Roles.AsNoTracking().OrderBy(row => row.Id)
                .Select(row => new { row.Id, row.Name, row.Description, row.CreatedDate, row.ModifiedDate }).ToArrayAsync(),
            Signatures = await db.SignatureImageFiles.AsNoTracking()
                .Where(row => excludedSignatureId == null || row.Id != excludedSignatureId)
                .OrderBy(row => row.Id).ToArrayAsync()
        });
    }
}
